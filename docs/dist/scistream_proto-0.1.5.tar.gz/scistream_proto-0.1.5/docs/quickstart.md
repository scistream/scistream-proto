## Tutorial

### Installation

~~~
pip install scistream
~~~

### Start Control server

~~~
$ python src/s2cs.py --verbose
Server started on 0.0.0.0:5000
~~~

### Send request using Scistream Client
After that let's send a request:

~~~
(scistream-proto-py3.9)$ python src/s2uc.py prod-req
uid; s2cs; access_token; role
3bca6862-78f3-11ee-90c6-9801a78d65ff localhost:5000 INVALID_TOKEN PROD
waiting for hello message
started client request
~~~

### Run Application controller mock
~~~
python src/appcontroller.py create-appctrl 3bca6862-78f3-11ee-90c6-9801a78d65ff 10.130.134.2:5000 AgpQoBo1VvvYkz8yYxyQgkgrW7nobYmG6dno8q8rgKG9MMYDM2IvCjgEezy8mqJpqvMl44GDq5GKayTyvkXn4fdmoB2 PROD 10.133.139.2
~~~
